-- voy a crear la data para la base de datos 
CREATE DATABASE IF NOT EXISTS techsolutions;
-- voy a utilizar la base creada
USE techsolutions;
-- creo la primer tabla idependiente para la primer entidad independiente del modelo MER
CREATE TABLE departamentos(
    Id_departamento INT UNIQUE NOT NULL PRIMARY KEY,
    nombre_departamento VARCHAR(50) NOT NULL,
    ubicacion_departamento VARCHAR(50) NOT NULL,
    telefono_departamento VARCHAR(50) NOT NULL
);
-- ahora creo la segunda tabla independiente a partir del modelo MER
CREATE TABLE cargos(
    Id_cargo INT UNIQUE NOT NULL PRIMARY KEY,
    nombre_cargo VARCHAR(50) NOT NULL,
    sueldo_base DECIMAL(10,2) NOT NULL
);
CREATE TABLE empleados(
    Id_empleado INT UNIQUE NOT NULL PRIMARY KEY,
    Id_departamento INT NOT NULL,
    Id_cargo INT NOT NULL,
    nombre_empleado VARCHAR(50) NOT NULL,
    nombredos_empleado VARCHAR(50) NOT NULL,
    apellido_empleado VARCHAR(50) NOT NULL,
    apellidodos_empleado VARCHAR(50) NOT NULL,
    genero VARCHAR(10) NOT NULL,
    cedula VARCHAR(20) NOT NULL,
    fecha_nacimiento DATE NOT NULL,
    telefono_empleado VARCHAR(20) NOT NULL,
    correo_electronico VARCHAR(100) NOT NULL,
    direccion VARCHAR(100) NOT NULL,
    fecha_contrato DATE NOT NULL,

    CONSTRAINT fk_empleado_departamento FOREIGN KEY(Id_departamento) REFERENCES departamentos(id_departamento),
    CONSTRAINT fk_empleado_cargo FOREIGN KEY(Id_cargo) REFERENCES cargos(id_cargo)
);


CREATE TABLE proyectos(
    Id_proyecto INT PRIMARY KEY,
    nombre_proyectos VARCHAR(100) NOT NULL,
    fecha_inicio DATE NOT NULL,
    fecha_fin DATE NOT NULL,
    estado_proyecto VARCHAR(20) NOT NULL
);
CREATE TABLE empleado_proyectos(
    Id_empleado_proyecto INT PRIMARY KEY,
    Id_empleado INT NOT NULL,
    Id_proyecto INT NOT NULL,
    fecha_asignacion DATE NOT NULL,
    rol_en_proyecto VARCHAR(50) NOT NULL,
    horas_asignadas INT NOT NULL,

    CONSTRAINT fk_empleado_proyecto_empleado FOREIGN KEY(id_empleado) REFERENCES empleados(id_empleado),
    CONSTRAINT fk_empleado_proyecto_proyecto FOREIGN KEY(id_proyecto) REFERENCES proyectos(id_proyecto)
);