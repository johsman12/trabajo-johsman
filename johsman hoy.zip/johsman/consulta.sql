-- consultamos la tabla de departamento con SELECT * FROM
SELECT * FROM departamentos;
-- consultamos la tabla de cargos con SELECT * FROM
SELECT * FROM cargos;
-- consultamos la tabla de proyectos con SELECT * FROM
SELECT * FROM proyectos;
-- consultamos la tabla de empleado_proyectos con SELECT * FROM
SELECT * FROM empleado_proyectos;
-- Listamos todos los empleados 
SELECT * FROM empleados;
-- Mostramos nombres y correos de los empleados 
SELECT Nombre_empleado, correo_electronico FROM empleados;
-- WHERE con igualdad: Empleados del departamento TI (id = 1) 
SELECT *FROM empleados WHERE Id_departamento = 1;
--  WHERE con AND: Mujeres del departamento de TI 
SELECT *FROM empleados WHERE genero = 'F'  AND id_departamento = 4;
-- WHERE con OR e Empleados del departamento TI o Marketing 
SELECT*FROM empleados WHERE Id_departamento = 1  OR Id_departamento = 2;
-- LIKE: Apellidos que empiezan con 'M' 
SELECT *FROM empleados WHERE apellido_empleado LIKE 'M%';
--  BETWEEN: Empleados contratados entre 2020 y 2022 
SELECT *FROM empleados WHERE fecha_contrato BETWEEN '2020-01-01' AND '2022-12-31';
-- Mayor que, Cargos con salario base mayor a 4000 
SELECT *FROM cargos WHERE sueldo_base > 4000;
-- Menor que, Empleados nacidos después de 1990 
SELECT *FROM empleados WHERE fecha_nacimiento > '1990-01-01';
-- Combinación LIKE y AND 
SELECT *FROM empleados WHERE apellido_empleado LIKE 'M%' AND genero = 'F';